package packageassignment.bank;

abstract public class Account {
	int accountId;
	String accountName;
	double balance;

	public Account(int accountId, String accountName, double balance) {
		this.accountId = accountId;
		this.accountName = accountName;
		this.balance = balance;
	}

	public void deposit(double amount) {
		balance = balance + amount;
		System.out.println("Deposited: " + amount);
		System.out.println("New Balance: " + balance);
	}

	public void withdraw(double amount) {
		balance = balance - amount;
		System.out.println("Withdrawn: " + amount);
		System.out.println("New Balance: " + balance);
	}

	public abstract void calInterest();

}
