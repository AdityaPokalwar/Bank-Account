package packageassignment.bank;

public class LoanAccount extends Account {
	double loanAmount;
	double interestRate;
//	double repaidAmount;

	public LoanAccount(int accountId, String accountName, double loanAmount, double interestRate) {
		super(accountId, accountName, -loanAmount);
		this.loanAmount = loanAmount;
		this.interestRate = interestRate;
	}

	@Override
	public void deposit(double amount) {
		if (balance < 0) {
			if (balance == (-1 * amount)) {
				balance = balance + amount;
				System.out.println("Deposited: " + amount);
				System.out.println("New Balance: " + balance);
				System.out.println(amount + " amount paid.");
			} else {
				System.out.println("deposit amount " + (-1 * balance));
			}
		} else {
			System.out.println("you paid all amount of loan.");
		}
	}

	@Override
	public void withdraw(double amount) {
		System.out.println("This is Loan Account. Withdrawal not allowed.");
	}

	@Override
	public void calInterest() {
		double interest = balance * (interestRate / 100);
		balance = balance + interest;
		System.out.println("Interest calculated: " + interest);
		System.out.println("New Balance: " + balance);
	}

}
