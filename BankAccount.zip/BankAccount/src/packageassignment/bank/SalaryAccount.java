package packageassignment.bank;

import java.util.Date;

public class SalaryAccount extends Account {
	int transactionCount = 0;
	final long FREEZETIMELIMIT = 60*24*60*60; //days x hours x minute x seconds = 2 months
	Date transactionDate;

	public SalaryAccount(int accountId, String accountName, double balance) {
		super(accountId, accountName, balance);
		this.transactionCount++;
		this.transactionDate = new Date();
	}

	public long checkTransaction(Date currentDate) {

		long dateDifference = currentDate.getTime() - transactionDate.getTime();
		long dateDifferenceInSec = dateDifference / 1000;
		if (dateDifferenceInSec > FREEZETIMELIMIT) {
			transactionCount = 0;
		}
		return transactionCount;

	}

	@Override
	public void withdraw(double amount) {
		balance = balance - amount;
		System.out.println("Withdrawn: " + amount);
		System.out.println("New Balance: " + balance);
		transactionCount++;

	}

	@Override
	public void calInterest() {
		double interestRate = 0.05; // 5% interest rate
		double interest = balance * interestRate;
		balance = balance + interest;
		System.out.println("Interest calculated: " + interest);
		System.out.println("New Balance: " + balance);
		transactionCount++;
	}
}
