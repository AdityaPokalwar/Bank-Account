package packageassignment.bank;

import java.util.Date;
import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("How many account do you want to add?");
		int noOfAccount = sc.nextInt();
		Account[] acc = new Account[noOfAccount];
		int accountIdCounter = 0;
		int choice;

		do {
			System.out.println("------------------------------------------");
			System.out.println("Press 1 to open account");
			System.out.println("Press 2 to Login");
			System.out.println("Press 3 to close account");
			choice = sc.nextInt();
			switch (choice) {

			// open account
			case 1:
				int subchoice;
				do {
					System.out.println("------------------------------------------");
					System.out.println("Select an option");
					System.out.println("1. Open a Savings Account");
					System.out.println("2. Open a Salary Account");
					System.out.println("3. Open a Current Account");
					System.out.println("4. Open a Loan Account");
					System.out.println("5. Back");
					subchoice = sc.nextInt();
					switch (subchoice) {
					case 1:
						if (accountIdCounter < noOfAccount) {
							System.out.println("Enter account name:");
							String savingsAccountName = sc.next();
							System.out.println("Enter initial balance(min 10,000):");
							double savingsAccountBalance = sc.nextDouble();
							Account savingAccount = new SavingsAccount(accountIdCounter + 1, savingsAccountName,
									savingsAccountBalance);
							acc[accountIdCounter++] = savingAccount;
							System.out.println("Savings account created successfully.");
							System.out.println("Your Account Number is : " + savingAccount.accountId);
							System.out.println("------------------------------------------");
						} else {
							System.out.println("Maximum account limit reached.");
							System.out.println("------------------------------------------");
						}
						break;
					case 2:
						if (accountIdCounter < noOfAccount) {
							System.out.println("Enter account name:");
							String salaryAccountName = sc.next();
							System.out.println("Enter initial balance:");
							double salaryAccountBalance = sc.nextDouble();
							Account salaryAccount = new SalaryAccount(accountIdCounter + 1, salaryAccountName,
									salaryAccountBalance);
							// acc[i] = new SalaryAccount(accountIdCounter++, salaryAccountName,
							// salaryAccountBalance);
							// acc[i] = new SalaryAccount(1002, "xyz", 1000, overdraft limit= 0);
							acc[accountIdCounter++] = salaryAccount;
							System.out.println("Salary account created successfully.");
							System.out.println("Your Account Number is : " + salaryAccount.accountId);
							System.out.println("------------------------------------------");
						} else {
							System.out.println("Maximum account limit reached.");
							System.out.println("------------------------------------------");
						}

						break;
					case 3:
						if (accountIdCounter < noOfAccount) {
							System.out.println("Enter account name:");
							String currentAccountName = sc.next();
							System.out.println("Enter initial balance:");
							double currentAccountBalance = sc.nextDouble();
							System.out.println("Enter overdraft limit:");
							double overdraftLimit = sc.nextDouble();
							Account currentAccount = new CurrentAccount(accountIdCounter + 1, currentAccountName,
									currentAccountBalance, overdraftLimit);
							acc[accountIdCounter++] = currentAccount;
							System.out.println("Current account created successfully.");
							System.out.println("Your Account Number is : " + currentAccount.accountId);
							System.out.println("------------------------------------------");
						} else {
							System.out.println("Maximum account limit reached.");
							System.out.println("------------------------------------------");
						}
						break;
					case 4:
						if (accountIdCounter < noOfAccount) {
							System.out.println("Enter account name:");
							String loanAccountName = sc.next();
							System.out.println("Enter loan amount:");
							double loanAmount = sc.nextDouble();
							System.out.println("Enter interest rate:");
							double interestRate = sc.nextDouble();
							Account loanAccount = new LoanAccount(accountIdCounter + 1, loanAccountName, loanAmount,
									interestRate);
							acc[accountIdCounter++] = loanAccount;
							System.out.println("Loan account created successfully.");
							System.out.println("Your Account Number is : " + loanAccount.accountId);
							System.out.println("------------------------------------------");
						} else {
							System.out.println("Maximum account limit reached.");
							System.out.println("------------------------------------------");
						}
						break;
					case 5:
						System.out.println("Existing the account opening");
						System.out.println("------------------------------------------");
						break;
					default:
						System.out.println("Envalid Choice ! Please try again.");
						System.out.println("------------------------------------------");
					}

				} while (subchoice != 5);
				break;

			// login
			case 2:
				if (accountIdCounter == 0) {
					System.out.println("Account not available. Please create an account first.");
					System.out.println("------------------------------------------------------");
					return;
				}
				System.out.println("Enter your account number: ");
				int accno = sc.nextInt();
				Account ac = null;

				for (int j = 0; j < noOfAccount; j++) {
					if (acc[j].accountId == accno) {
						ac = acc[j];
						System.out.println("------------------------------------------");
						System.out.println("Login Successful");
						break;
					}
				}
				if (ac == null) {
					System.out.println("------------------------------------------");
					System.out.println("Account not found!");
					return;
				}

				if (ac instanceof SalaryAccount) {
					SalaryAccount salaryAccount = (SalaryAccount) ac;
					Date currentDate = new Date();
					salaryAccount.checkTransaction(currentDate);
					if (salaryAccount.transactionCount == 0) {
						System.out.println("Your Account is Frozen.");
						return;
					}
					System.out.println(salaryAccount.transactionCount);

				}

				int operationChoice;
				do {
					System.out.println("Select an operation for account " + ac.accountId + ":");
					System.out.println("1. Deposit");
					System.out.println("2. Withdraw");
					System.out.println("3. Calculate Interest");
					System.out.println("4. Display Balance");
					System.out.println("5. Exit");

					operationChoice = sc.nextInt();

					switch (operationChoice) {
					case 1:
						System.out.println("Enter deposit amount:");
						double depositAmount = sc.nextDouble();
						ac.deposit(depositAmount);
						System.out.println("------------------------------------------");
						break;
					case 2:
						System.out.println("Enter withdrawal amount:");
						double withdrawalAmount = sc.nextDouble();
						ac.withdraw(withdrawalAmount);
						System.out.println("------------------------------------------");
						break;
					case 3:
						ac.calInterest();
						System.out.println("------------------------------------------");
						break;
					case 4:
						System.out.println("Account balance: " + ac.balance);
						System.out.println("------------------------------------------");
						break;

					case 5:
						System.out.println("Exiting account operations.");
						System.out.println("------------------------------------------");
						break;
					default:
						System.out.println("Invalid choice! Please try again.");
						System.out.println("------------------------------------------");
					}
				} while (operationChoice != 5);
				break;

			// exit
			case 3:
				System.out.println("Existing the program.");
				System.out.println("------------------------------------------");
				break;
			default:
				System.out.println("Invalid Choice! Please try again.");
				System.out.println("------------------------------------------");
			}
		} while (choice != 3);
		sc.close();
	}

}

		
