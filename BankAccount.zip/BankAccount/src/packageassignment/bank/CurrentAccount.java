package packageassignment.bank;

public class CurrentAccount extends Account {
	private double overdraft;

	public CurrentAccount(int accountId, String accountName, double balance, double overdraft) {
		super(accountId, accountName, balance);
		this.overdraft = overdraft;
	}

	@Override
	public void withdraw(double amount) {
		if (balance + overdraft >= amount) {
			super.withdraw(amount);
		} else {
			System.out.println("Insufficient balance. Exceeding overdraft limit.");
		}
	}

	@Override
	public void calInterest() {
		if (balance >= 1 && balance < 500000) {
			double interestRate = 0.02; // 2% interest rate
			double interest = balance * interestRate;
			balance = balance + interest;
			System.out.println("Interest calculated: " + interest);
			System.out.println("New Balance: " + balance);
		} else if (balance >= 500000) {
			double interestRate = 0.03; // 3% interest rate
			double interest = balance * interestRate;
			balance = balance + interest;
			System.out.println("Interest calculated: " + interest);
			System.out.println("New Balance: " + balance);
		} else {
			// no interest calculation happens
			System.out.println("your balance is in minus.");
		}

	}
}

