package packageassignment.bank;

public class SavingsAccount extends Account {
	final double MINIMUMBALANCE = 10000;

	public SavingsAccount(int accountId, String accountName, double balance) {
		super(accountId, accountName, balance);
	}

	@Override
	public void withdraw(double amount) {
		if ((balance - amount) >= MINIMUMBALANCE)
			super.withdraw(amount);
		else
			System.out.println("Insufficient balance. Minimum balance should be maintained.");

	}

	@Override
	public void calInterest() {
		double interestRate = 0.03; // 3% interest rate
		double interest = balance * interestRate;
		balance = balance + interest;
		System.out.println("Interest calculated: " + interest);
		System.out.println("New Balance: " + balance);
	}
}
